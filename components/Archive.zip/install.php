<?php
	$wow = mysqli_connect("localhost", "akolinko", "kgdskk");
	$val = mysqli_query($wow, "show databases like 'camagru'");
	$res = mysqli_num_rows($val);
	if (!$res)
	{

	$query = mysqli_query($wow, "CREATE DATABASE IF NOT EXISTS `camagru`");
	$wow = mysqli_connect("localhost", "akolinko", "kgdskk", "camagru");

	$query = mysqli_query($wow, "CREATE TABLE IF NOT EXISTS `comment` (
        `id` int(11) NOT NULL,
  		`user_id` int(11) NOT NULL,
  		`foto_id` int(11) NOT NULL,
  		`comment` text NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=utf8");

	$query = mysqli_query($wow, "CREATE TABLE IF NOT EXISTS `foto` (
	  `id` int(11) NOT NULL,
	  `name` varchar(255) NOT NULL,
	  `user_id` int(11) NOT NULL,
	  `img` varchar(255) NOT NULL
	  )ENGINE=InnoDB DEFAULT CHARSET=utf8");

	$query = mysqli_query($wow, "INSERT INTO `foto` (`id`, `name`, `user_id`, `img`) VALUES
	(1, '123', 1, '/resurses/1.jpg'),
	(2, '221', 2, '/resurses/avatar.png'),
	(3, '334', 3, '/resurses/2.png')");

        $query = mysqli_query($wow, "CREATE TABLE IF NOT EXISTS `register` (
	  `id` int(11) NOT NULL,
	  `user_name` varchar(255) NOT NULL,
	  `password` varchar(255) NOT NULL,
	  `admin` int(11) NOT NULL  DEFAULT '0',
	  `act_email` int(10) UNSIGNED NOT NULL,
	  `email` varchar(255) NOT NULL,
	  `hash_email` varchar(255) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $query = mysqli_query($wow, "INSERT INTO `register` (`id`, `user_name`, `password`, `admin`, `act_email`, `email`, `hash_email`) VALUES
	(38, 'admin', 'cf09c171997917f5271ac2af9205e9d89333e127fcadfecf434399e9e127b645778bd0c36b8661f395af73b2b904d2f25287ec800e404c8e4118bc31521757de', 1, 1, 'lol@dsa.ds', '61547a0d')
	");

	$query = mysqli_query($wow, "CREATE TABLE IF NOT EXISTS `like` (
		`id` int(11) NOT NULL,
		`user_id` int(11) NOT NULL,
		`foto_id` int(11) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8");


	$query = mysqli_query($wow, "ALTER TABLE `comment` ADD PRIMARY KEY (`id`)");
	$query = mysqli_query($wow, "ALTER TABLE `foto` ADD PRIMARY KEY (`id`)");
	$query = mysqli_query($wow, "ALTER TABLE `register` ADD PRIMARY KEY (`id`)");
	$query = mysqli_query($wow, "ALTER TABLE `like` ADD PRIMARY KEY (`id`)");



	$query = mysqli_query($wow, "ALTER TABLE `comment` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78");

	$query = mysqli_query($wow, "ALTER TABLE `foto` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307");

	$query = mysqli_query($wow, "ALTER TABLE `register` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48");

	$query = mysqli_query($wow, "ALTER TABLE `like` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68");
	}

?>


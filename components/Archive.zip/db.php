<?php 
//	session_start();

	require_once 'install.php';


class Db
{

    public static function getConnection()
    {
        $paramsPath = ROOT . '/config/db_params.php';
        $params = include($paramsPath);


        $dsn = "mysql:host={$params['host']};dbname={$params['dbname']}";
        $db = new PDO($dsn, $params['user'], $params['password']);
        $db->exec("set names utf8");

        return $db;
    }

}

	ini_set('error_reporting', E_ALL);
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);

	define('HOST','localhost');
	define('LOGIN', 'akolinko');
	define('PASSWORD', 'kgdskk');
	define('DATABASE', 'camagru');

	define('DIR', dirname(__FILE__));

	$db = mysqli_connect(HOST, LOGIN, PASSWORD, DATABASE);

	if (mysqli_connect_errno())
	{
		echo "ERROR: DATABASE DIDN'T CONNECT! # ".mysqli_connect_errno();
		exit();
	}

	$query = "SELECT * FROM "
?>